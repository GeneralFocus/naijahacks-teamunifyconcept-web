<?php


use Stichoza\GoogleTranslate\TranslateClient;
 

     // initializing Translation class 
   $translate = TranslateClient('en','ka');

 /**$text = "this is fine ";

 $from = "en";
 $to ="fr";
 $gt = file_get_contents("http://ajax.googleapis.com/ajax/services/language/translate?v=1.0&q=".urlencode($text)."&langpair=".$from."|".$to);
 $json = json_encode($gt,true);
 if($json['responseStatus'] == 200){
 	echo $json['responseData']['translatedText'];
 }else{

 	 if ($json['responseDetails']) {

 	 	echo $json['responseDetails']."error_log";
 	 }else{
        echo "Something is'nt right";

 	 }
 }**/

 ?>