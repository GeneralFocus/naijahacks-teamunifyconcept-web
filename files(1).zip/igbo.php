<!doctype html>
<html lang="en">
<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="icon" href="img/favicon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
        <title>Igbo</title>
        
        <!-- Bootstrap CSS -->
   

        <link rel="stylesheet" href="css/responsive.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link href="css/ResponsiveDashboard.min.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/header.css">
         <script async src="js/google.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-4062475662821332",
    enable_page_level_ads: true
  });
</script>
    </head>
    <style type="text/css">
      
    </style>
    <body>
    <?php include ("head_foot/header.php");?>
        <section>
            
              <div class="content-wrapper" style=" min-height: 562px;">
                <div class="row">
             <ul class="nav nav-tabs">
  <li  style="cursor: pointer;" id="letter"><a> Letters</a></li>
  <li style="cursor: pointer;" id="Number"><a >Number</a></li>
  <li style="cursor: pointer;" id="Vocabulary"><a >Vocabulary</a></li>
  <li style="cursor: pointer;" id="Phrases"><a >Phrases</a></li>
  <li style="cursor: pointer;" id="Grammar"><a >Grammar</a></li>
</ul>
            </div>

              <div class="container" id="letters" style="display:block;">
            <br/>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Pronounciation</big> <dfn></dfn></td></tr>
<tr><td><big>a</big><dfn></dfn></td>
<td><big>a</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>
<tr><td><big>b</big> <dfn></dfn></td>
<td><big>b</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>c</big> <dfn></dfn></td>
<td><big></big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>d</big> <dfn></dfn></td>
<td><big>d</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>e</big> <dfn></dfn></td>
<td><big>e </big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>e</big> <dfn></dfn></td>
<td><big>e </big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>f</big> <dfn></dfn></td>
<td><big>f</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>g</big> <dfn></dfn></td>
<td><big>g</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big> </big> <dfn></dfn></td>
<td><big>gb</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>h</big> <dfn></dfn></td>
<td><big>h</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>j</big> <dfn></dfn></td>
<td><big>j</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>k</big> <dfn></dfn></td>
<td><big>k</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>l</big> <dfn></dfn></td>
<td><big>l</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>m</big> <dfn></dfn></td>
<td><big>m</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>n</big> <dfn></dfn></td>
<td><big>n</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>o</big> <dfn></dfn></td>
<td><big>o</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big> </big> <dfn></dfn></td>
<td><big>o</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>p</big> <dfn></dfn></td>
<td><big>p</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>q</big> <dfn></dfn></td>
<td><big></big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>r</big> <dfn></dfn></td>
<td><big>r</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>s</big> <dfn></dfn></td>
<td><big>s</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big> </big> <dfn></dfn></td>
<td><big>s</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big> t</big> <dfn></dfn></td>
<td><big>t</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>u</big> <dfn></dfn></td>
<td><big>u</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>w</big> <dfn></dfn></td>
<td><big>w</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>y </big> <dfn></dfn></td>
<td><big>y</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>

        <div class="container" id="numbers" style="display:none;">
            <br/>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>Engligh </big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Pronounciation</big> <dfn></dfn></td></tr>
<tr><td><big>one</big> <dfn>(1)</dfn></td>
<td><big>okan</big> <dfn>(1)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>two</big><dfn>(2)</dfn></td>
<td><big>eji</big> <dfn>(2)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>three</big><dfn>(3)</dfn></td>
<td><big>eta</big> <dfn>(3)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>four</big><dfn>(4)</dfn></td>
<td><big>erin</big> <dfn>(4)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>five</big><dfn>(5)</dfn></td>
<td><big>aarun</big> <dfn>(5)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>six</big><dfn>(6)</dfn></td>
<td><big>efa</big> <dfn>(6)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>seven</big><dfn>(7)</dfn></td>
<td><big>eje</big> <dfn>(7)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>eight</big><dfn>(8)</dfn></td>
<td><big>ejo</big> <dfn>(8)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>nine</big><dfn>(9)</dfn></td>
<td><big>eesan</big> <dfn>(9)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>ten</big><dfn>(10)</dfn></td>
<td><big>ewa</big> <dfn>(10)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>eleven</big><dfn>(11)</dfn></td>
<td><big>mokanla</big> <dfn>(11)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>twelve</big><dfn>(12)</dfn></td>
<td><big>mejila</big> <dfn>(12)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>thirteen</big><dfn>(13)</dfn></td>
<td><big>metala</big> <dfn>(13)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>fourteen</big><dfn>(14)</dfn></td>
<td><big>merinla</big> <dfn>(14)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>fiveteen</big><dfn>(15)</dfn></td>
<td><big>medogun</big> <dfn>(15)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>sixteen</big><dfn>(16)</dfn></td>
<td><big>erin dinlogun</big> <dfn>(16)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>seventeen</big><dfn>(17)</dfn></td>
<td><big>eta dinlogun</big> <dfn>(17)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>eighteen</big><dfn>(18)</dfn></td>
<td><big>eji dinlogun</big> <dfn>(18)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>nineteen</big><dfn>(19)</dfn></td>
<td><big>okan dinlogun</big> <dfn>(19)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>twenty</big><dfn>(20)</dfn></td>
<td><big>ogun</big> <dfn>(20)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>

        <div class="container" id="vocabularies" style="display:none;">
            <br/>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>And</big>: <dfn>ati</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td></tr>
<tr><td><big>And</big>: <dfn>ati</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td></tr>
<tr><td><big>And</big>: <dfn>ati</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>

        <div class="container" id="phrases" style="display:none;">
            <br/>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>And</big>: <dfn>ati</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td></tr>
<tr><td><big>And</big>: <dfn>ati</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td></tr>
<tr><td><big>And</big>: <dfn>ati</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>

        <div class="container" id="grammars" style="display:none;">
            <br/>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>And</big>: <dfn>ati</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td></tr>
<tr><td><big>And</big>: <dfn>ati</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td></tr>
<tr><td><big>And</big>: <dfn>ati</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td>
<td><big>Under</big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>
         
       
        </div>
       </section>
       
       <?php include ("head_foot/footer.php");?>
 <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/googleNew.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="js/app.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/page.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
             

             $(document).ready(function(){
    $( "#letter" ).click(function(){
        $("#letters").css("display","block");
        $("#numbers").css("display","none");
        $("#grammars").css("display","none");
        $("#phrases").css("display","none");
        $("#vocabularies").css("display","none");
        // $("#number").hide();
    });

      $( "#Number" ).click(function(){
        $("#letters").css("display","none");
         $("#grammars").css("display","none");
        $("#phrases").css("display","none");
        $("#vocabularies").css("display","none");
        $("#numbers").css("display","block");
        // $("#number").hide();
    }); $( "#Grammar" ).click(function(){
        $("#letters").css("display","none");
         $("#grammars").css("display","block");
        $("#phrases").css("display","none");
        $("#vocabularies").css("display","none");
        $("#numbers").css("display","none");
        // $("#number").hide();
    }); $( "#Vocabulary" ).click(function(){
        $("#letters").css("display","none");
         $("#grammars").css("display","none");
        $("#phrases").css("display","none");
        $("#vocabularies").css("display","block");
        $("#numbers").css("display","none");
        // $("#number").hide();
    }); $( "#Phrases" ).click(function(){
        $("#letters").css("display","none");
         $("#grammars").css("display","none");
        $("#phrases").css("display","block");
        $("#vocabularies").css("display","none");
        $("#numbers").css("display","none");
        // $("#number").hide();
    });
});
       </script>
    </body>
    </html>
