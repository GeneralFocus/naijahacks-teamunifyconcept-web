<!doctype html>
<html lang="en">
<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="icon" href="img/favicon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
        <title>Hausa</title>
        
        <!-- Bootstrap CSS -->
   

        <link rel="stylesheet" href="css/responsive.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link href="css/ResponsiveDashboard.min.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/header.css">
         <script async src="js/google.js"></script>

    </head>
    <style type="text/css">
      
    </style>
    <body>
    <?php include ("head_foot/header.php");?>
       <section>
            
              <div class="content-wrapper" style=" min-height: 562px;">
                <div class="row">
             <ul class="nav nav-tabs">
  <li  style="cursor: pointer;" id="letter"><a> Letters</a></li>
  <li style="cursor: pointer;" id="Number"><a >Number</a></li>
  <li style="cursor: pointer;" id="Vocabulary"><a >Vocabulary</a></li>
  <li style="cursor: pointer;" id="Phrases"><a >Phrases</a></li>
  <li style="cursor: pointer;" id="Grammar"><a >Grammar</a></li>
</ul>
            </div>

              <div class="container" id="letters" style="display:block;">
            <br/>
            <h1>Hausa Language has 30 Letters</h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Hausa</big> <dfn></dfn></td>
<td><big>Pronounciation</big> <dfn></dfn></td></tr>
<tr><td><big>a</big><dfn></dfn></td>
<td><big>a</big> <dfn></dfn></td>
<td><big></big>: <dfn><audio controls>
  <source src="audio/a.3gpp" type="audio/mpeg">
</audio></dfn></td></tr>

<tr><td><big>b</big> <dfn></dfn></td>
<td><big>b</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>ɓ</big> <dfn></dfn></td>
<td><big>ɓ</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>c</big> <dfn></dfn></td>
<td><big>/tʃ/</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>d</big> <dfn></dfn></td>
<td><big>d</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>ɗ </big> <dfn></dfn></td>
<td><big>ɗ  </big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>e</big> <dfn></dfn></td>
<td><big>e </big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>e</big> <dfn></dfn></td>
<td><big>e </big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>f</big> <dfn></dfn></td>
<td><big>/ɸ/</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>g</big> <dfn></dfn></td>
<td><big>g</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>h</big> <dfn></dfn></td>
<td><big>h</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>i</big> <dfn></dfn></td>
<td><big>i</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>j</big> <dfn></dfn></td>
<td><big>/(d)ʒ/</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>k</big> <dfn></dfn></td>
<td><big>k</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>kʼ</big> <dfn></dfn></td>
<td><big>/kʼ/</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>l</big> <dfn></dfn></td>
<td><big>l</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>m</big> <dfn></dfn></td>
<td><big>m</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>n</big> <dfn></dfn></td>
<td><big>n</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>r</big> <dfn></dfn></td>
<td><big>/ɽ/</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>r̃  </big> <dfn></dfn></td>
<td><big>/r/</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>s</big> <dfn></dfn></td>
<td><big>s</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>sh</big> <dfn></dfn></td>
<td><big>/ʃ/</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big> t</big> <dfn></dfn></td>
<td><big>t</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big> ts</big> <dfn></dfn></td>
<td><big>/(t)sʼ/</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>u</big> <dfn></dfn></td>
<td><big>u</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>w</big> <dfn></dfn></td>
<td><big>w</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>y </big> <dfn></dfn></td>
<td><big>/j/</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>z </big> <dfn></dfn></td>
<td><big>/z/</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>ʼ </big> <dfn></dfn></td>
<td><big>/ʔ/</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>

        <div class="container" id="numbers" style="display:none;">
            <br/>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>Engligh </big> <dfn></dfn></td>
<td><big>Hausa</big> <dfn></dfn></td>
<td><big>Pronounciation</big> <dfn></dfn></td></tr>
<tr><td><big>one</big> <dfn>(1)</dfn></td>
<td><big>daya</big> <dfn>(1)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>two</big><dfn>(2)</dfn></td>
<td><big>biyu a</big> <dfn>(2)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>three</big><dfn>(3)</dfn></td>
<td><big>uku</big> <dfn>(3)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>four</big><dfn>(4)</dfn></td>
<td><big>hu?u</big> <dfn>(4)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>five</big><dfn>(5)</dfn></td>
<td><big>biyar</big> <dfn>(5)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>six</big><dfn>(6)</dfn></td>
<td><big>shida</big> <dfn>(6)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>seven</big><dfn>(7)</dfn></td>
<td><big>bakwai</big> <dfn>(7)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>eight</big><dfn>(8)</dfn></td>
<td><big>takwas</big> <dfn>(8)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>nine</big><dfn>(9)</dfn></td>
<td><big>tara</big> <dfn>(9)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>ten</big><dfn>(10)</dfn></td>
<td><big>goma</big> <dfn>(10)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>

        <div class="container" id="vocabularies" style="display:none;">
            <br/>
            <h1>Numbering </h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>
<tr><td><big>one</big> <dfn>(1)</dfn></td>
<td><big>daya</big> <dfn>(1)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>two</big><dfn>(2)</dfn></td>
<td><big>biyu a</big> <dfn>(2)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>three</big><dfn>(3)</dfn></td>
<td><big>uku</big> <dfn>(3)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>four</big><dfn>(4)</dfn></td>
<td><big>hu?u</big> <dfn>(4)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>five</big><dfn>(5)</dfn></td>
<td><big>biyar</big> <dfn>(5)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>six</big><dfn>(6)</dfn></td>
<td><big>shida</big> <dfn>(6)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>seven</big><dfn>(7)</dfn></td>
<td><big>bakwai</big> <dfn>(7)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>eight</big><dfn>(8)</dfn></td>
<td><big>takwas</big> <dfn>(8)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>nine</big><dfn>(9)</dfn></td>
<td><big>tara</big> <dfn>(9)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>ten</big><dfn>(10)</dfn></td>
<td><big>goma</big> <dfn>(10)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>
 </tbody></table>
</div>
 <br/>  
   <h1>Days of the week </h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>Sunday</big> <dfn> </dfn></td>
<td><big>lahadi</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Monday</big> <dfn> </dfn></td>
<td><big>litinin</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Tuesday</big> <dfn></dfn></td>
<td><big>talata</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>Wednesday</big> <dfn></dfn></td>
<td><big>laraba</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Thursday</big> <dfn></dfn></td>
<td><big>alhamis</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Firday</big> <dfn></dfn></td>
<td><big>jumma'a</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Saturday</big> <dfn></dfn></td>
<td><big>asabar</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
<br/> 
    <h1>Colours </h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>Red</big> <dfn> </dfn></td>
<td><big>jajata</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Green</big> <dfn> </dfn></td>
<td><big>tsanwa</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Blue</big> <dfn></dfn></td>
<td><big>shu?i</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>Black</big> <dfn></dfn></td>
<td><big>ba?i</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>White</big> <dfn></dfn></td>
<td><big>fari</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Grey</big> <dfn></dfn></td>
<td><big>tokatoka</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


 </tbody></table>
</div>
<br/> 
   <h1>Fruit </h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Hausa</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>Potatoes</big> <dfn> </dfn></td>
<td><big>dankali</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Tomatoes</big> <dfn> </dfn></td>
<td><big>tumatir</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Bananas</big> <dfn></dfn></td>
<td><big>ayaba</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Apple</big> <dfn></dfn></td>
<td><big>aful</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Dathe </big> <dfn></dfn></td>
<td><big>dathe</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>

        <div class="container" id="phrases" style="display:none;">
            <br/> 
            <h1>Phrase </h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Hausa</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>What is your name?</big> <dfn> </dfn></td>
<td><big> yaya sunanka/ki/ku?</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Hi</big> <dfn></dfn></td>
<td><big> barka!</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>Nice to meet you</big> <dfn></dfn></td>
<td><big> naji dadin haduwarmu!</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>And you?</big> <dfn></dfn></td>
<td><big>kai fa?/ke fa?/ku fa?</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>A little bit </big> <dfn></dfn></td>
<td><big>ka?an</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>It was nice talking to you</big> <dfn></dfn></td>
<td><big>na ji dadin zancenmu</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>What is that called in Hausa?</big> <dfn></dfn></td>
<td><big>yaya ake kiran wannan abin a hausa?</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Where do you live? <dfn></dfn></td>
<td><big>a ina kake/kike/kuke zaune?</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>I'm a student</big> <dfn></dfn></td>
<td><big>ni ?alibi ne</big>: <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Go straight</big> <dfn></dfn></td>
<td><big> mike</big>: <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>

        <div class="container" id="grammars" style="display:none;">
                    <br/>  
            <h1>Grammar  </h1>
            <h4>Two letter words </h4>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>
<tr><td><big>We</big> <dfn> </dfn></td>
<td><big>mu</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>He</big> <dfn></dfn></td>
<td><big>shi</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>My</big> <dfn></dfn></td>
<td><big>nawa</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>in</big> <dfn></dfn></td>
<td><big>ciki</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>To</big> <dfn></dfn></td>
<td><big>ga</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>With</big> <dfn></dfn></td>
<td><big>da</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


 </tbody></table>
</div>
 <br/>
<h4>three letter words </h4>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>For</big> <dfn> </dfn></td>
<td><big>don</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>But</big> <dfn> </dfn></td>
<td><big>amma</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Who?</big> <dfn></dfn></td>
<td><big>wa?</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>How?</big> <dfn></dfn></td>
<td><big>yaya?</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>head</big> <dfn></dfn></td>
<td><big>ori</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>You</big> <dfn></dfn></td>
<td><big>kai</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Our</big> <dfn></dfn></td>
<td><big>namu</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
<br/>  
   <h4>Pronoun </h4>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>you</big> <dfn> </dfn></td>
<td><big>kai</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>We</big> <dfn> </dfn></td>
<td><big>mu</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>His</big> <dfn></dfn></td>
<td><big>nashi</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>I</big> <dfn></dfn></td>
<td><big>ni</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>she</big> <dfn></dfn></td>
<td><big>ita</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>he</big> <dfn></dfn></td>
<td><big>shi</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Her</big> <dfn></dfn></td>
<td><big>nata</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
<br/> 
   <h1>Noun </h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>milk</big> <dfn> </dfn></td>
<td><big>madara</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>France</big> <dfn> </dfn></td>
<td><big>faransa</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>German</big> <dfn></dfn></td>
<td><big>jamusanci</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
<br/> 
   <h1>Forming Sentences </h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>Where are you coming from?</big> <dfn></dfn></td>
<td><big>ni bo ni o tin bo</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>No problem</big> <dfn></dfn></td>
<td><big>ba illa</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>I understand you</big> <dfn> </dfn></td>
<td><big>na fahimce ka/ki/ku</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>I don't understand you</big> <dfn> </dfn></td>
<td><big>ban fahimce ka/ki/ku ba</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>I don't speak French
</big> <dfn></dfn></td>
<td><big>ba na jin faransanci</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>This is my house</big> <dfn></dfn></td>
<td><big>wannan shi ne gidana</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>That restaurant is far</big> <dfn></dfn></td>
<td><big> gidan abincin nan yana da nisa</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>



 </tbody></table>
</div>
        </div>
         
       
        </div>
       </section> 
       <?php include ("head_foot/footer.php");?>
 <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/googleNew.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="js/app.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/page.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
             

             $(document).ready(function(){
    $( "#letter" ).click(function(){
        $("#letters").css("display","block");
        $("#numbers").css("display","none");
        $("#grammars").css("display","none");
        $("#phrases").css("display","none");
        $("#vocabularies").css("display","none");
        // $("#number").hide();
    });

      $( "#Number" ).click(function(){
        $("#letters").css("display","none");
         $("#grammars").css("display","none");
        $("#phrases").css("display","none");
        $("#vocabularies").css("display","none");
        $("#numbers").css("display","block");
        // $("#number").hide();
    }); $( "#Grammar" ).click(function(){
        $("#letters").css("display","none");
         $("#grammars").css("display","block");
        $("#phrases").css("display","none");
        $("#vocabularies").css("display","none");
        $("#numbers").css("display","none");
        // $("#number").hide();
    }); $( "#Vocabulary" ).click(function(){
        $("#letters").css("display","none");
         $("#grammars").css("display","none");
        $("#phrases").css("display","none");
        $("#vocabularies").css("display","block");
        $("#numbers").css("display","none");
        // $("#number").hide();
    }); $( "#Phrases" ).click(function(){
        $("#letters").css("display","none");
         $("#grammars").css("display","none");
        $("#phrases").css("display","block");
        $("#vocabularies").css("display","none");
        $("#numbers").css("display","none");
        // $("#number").hide();
    });
});
       </script>
    </body>
    </html>
