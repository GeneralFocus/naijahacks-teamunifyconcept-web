<!doctype html>
<html lang="en">
<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="icon" href="img/favicon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
        <title>Yoruba</title>
        
        <!-- Bootstrap CSS -->
   

        <link rel="stylesheet" href="css/responsive.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link href="css/ResponsiveDashboard.min.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/header.css">
         <script async src="js/google.js"></script>

    </head>
    <style type="text/css">
      
    </style>
    <body>
    <?php include ("head_foot/header.php");?>
        <section>
            
              <div class="content-wrapper" style=" min-height: 562px;">
                <div class="row">
             <ul class="nav nav-tabs">
  <li  style="cursor: pointer;" id="letter"><a> Letters</a></li>
  <li style="cursor: pointer;" id="Number"><a >Number</a></li>
  <li style="cursor: pointer;" id="Vocabulary"><a >Vocabulary</a></li>
  <li style="cursor: pointer;" id="Phrases"><a >Phrases</a></li>
  <li style="cursor: pointer;" id="Grammar"><a >Grammar</a></li>
</ul>
            </div>

              <div class="container" id="letters" style="display:block;">
            <br/>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Pronounciation</big> <dfn></dfn></td></tr>
<tr><td><big>a</big><dfn></dfn></td>
<td><big>a</big> <dfn></dfn></td>
<td><big></big>: <dfn><audio controls>
  <source src="audio/a.3gpp" type="audio/mpeg">
</audio></dfn></td></tr>

<tr><td><big>b</big> <dfn></dfn></td>
<td><big>b</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>c</big> <dfn></dfn></td>
<td><big></big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>d</big> <dfn></dfn></td>
<td><big>d</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>e</big> <dfn></dfn></td>
<td><big>e </big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>e</big> <dfn></dfn></td>
<td><big>e </big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>f</big> <dfn></dfn></td>
<td><big>f</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>g</big> <dfn></dfn></td>
<td><big>g</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big> </big> <dfn></dfn></td>
<td><big>gb</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>h</big> <dfn></dfn></td>
<td><big>h</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>i</big> <dfn></dfn></td>
<td><big>i</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>j</big> <dfn></dfn></td>
<td><big>j</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>k</big> <dfn></dfn></td>
<td><big>k</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>l</big> <dfn></dfn></td>
<td><big>l</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>m</big> <dfn></dfn></td>
<td><big>m</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>n</big> <dfn></dfn></td>
<td><big>n</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>o</big> <dfn></dfn></td>
<td><big>o</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big> </big> <dfn></dfn></td>
<td><big>o</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>p</big> <dfn></dfn></td>
<td><big>p</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>q</big> <dfn></dfn></td>
<td><big></big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>r</big> <dfn></dfn></td>
<td><big>r</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>s</big> <dfn></dfn></td>
<td><big>s</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big> </big> <dfn></dfn></td>
<td><big>s</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big> t</big> <dfn></dfn></td>
<td><big>t</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>u</big> <dfn></dfn></td>
<td><big>u</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>w</big> <dfn></dfn></td>
<td><big>w</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>y </big> <dfn></dfn></td>
<td><big>y</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>

        <div class="container" id="numbers" style="display:none;">
            <br/>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>Engligh </big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Pronounciation</big> <dfn></dfn></td></tr>
<tr><td><big>one</big> <dfn>(1)</dfn></td>
<td><big>okan</big> <dfn>(1)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>two</big><dfn>(2)</dfn></td>
<td><big>eji</big> <dfn>(2)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>three</big><dfn>(3)</dfn></td>
<td><big>eta</big> <dfn>(3)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>four</big><dfn>(4)</dfn></td>
<td><big>erin</big> <dfn>(4)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>five</big><dfn>(5)</dfn></td>
<td><big>aarun</big> <dfn>(5)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>six</big><dfn>(6)</dfn></td>
<td><big>efa</big> <dfn>(6)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>seven</big><dfn>(7)</dfn></td>
<td><big>eje</big> <dfn>(7)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>eight</big><dfn>(8)</dfn></td>
<td><big>ejo</big> <dfn>(8)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>nine</big><dfn>(9)</dfn></td>
<td><big>eesan</big> <dfn>(9)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>ten</big><dfn>(10)</dfn></td>
<td><big>ewa</big> <dfn>(10)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>eleven</big><dfn>(11)</dfn></td>
<td><big>mokanla</big> <dfn>(11)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>twelve</big><dfn>(12)</dfn></td>
<td><big>mejila</big> <dfn>(12)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>thirteen</big><dfn>(13)</dfn></td>
<td><big>metala</big> <dfn>(13)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>fourteen</big><dfn>(14)</dfn></td>
<td><big>merinla</big> <dfn>(14)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>fiveteen</big><dfn>(15)</dfn></td>
<td><big>medogun</big> <dfn>(15)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>sixteen</big><dfn>(16)</dfn></td>
<td><big>erin dinlogun</big> <dfn>(16)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>seventeen</big><dfn>(17)</dfn></td>
<td><big>eta dinlogun</big> <dfn>(17)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>eighteen</big><dfn>(18)</dfn></td>
<td><big>eji dinlogun</big> <dfn>(18)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>nineteen</big><dfn>(19)</dfn></td>
<td><big>okan dinlogun</big> <dfn>(19)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>twenty</big><dfn>(20)</dfn></td>
<td><big>ogun</big> <dfn>(20)</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>

        <div class="container" id="vocabularies" style="display:none;">
            <br/>
            <h1>Numbering <span style="text-decoration:underline;">means</span> <i style="color:#01415a;"><b>OhunKan Yoruba </b></i></h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>
<tr><td><big>one</big> <dfn> {i}</dfn></td>
<td><big>eyokan</big> <dfn>{i}</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>two</big> <dfn>{2}</dfn></td>
<td><big>meji</big> <dfn>{2}</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>three</big> <dfn>{3}</dfn></td>
<td><big>meta</big> <dfn>{3}</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>four</big> <dfn>{4}</dfn></td>
<td><big>merin</big> <dfn>{4}</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>five</big> <dfn>{5}</dfn></td>
<td><big>marun</big> <dfn>{5}</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>six</big> <dfn>{6}</dfn></td>
<td><big>mefa</big> <dfn>{6}</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>seven</big> <dfn>{7}</dfn></td>
<td><big>meje</big> <dfn>{7}</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>eight</big> <dfn>{8}</dfn></td>
<td><big>mejo</big> <dfn>{8}</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>nine</big> <dfn>{9}</dfn></td>
<td><big>mesan</big>: <dfn>{9}</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>ten</big> <dfn>{10}</dfn></td>
<td><big>mewa</big>: <dfn>{10}</dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
 <br/>  
   <h1>Days of the week <span style="text-decoration:underline;">means</span> <i style="color:#01415a;"><b>Ojo to wa ninu ose</b></i></h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>Sunday</big> <dfn> </dfn></td>
<td><big>aiku</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Monday</big> <dfn> </dfn></td>
<td><big>ojo aje</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Tuesday</big> <dfn></dfn></td>
<td><big>isegun</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>Wednesday</big> <dfn></dfn></td>
<td><big>ojorun</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Thursday</big> <dfn></dfn></td>
<td><big>ojobo</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Firday</big> <dfn></dfn></td>
<td><big>eti</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Saturday</big> <dfn></dfn></td>
<td><big>abameta</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
<br/> Ojo to wa ninu ose
   <h1>Colours <span style="text-decoration:underline;">means</span> <i style="color:#01415a;"><b>aawo</b></i></h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>Red</big> <dfn> </dfn></td>
<td><big>awo pupa</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Green</big> <dfn> </dfn></td>
<td><big>awo ewe</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Blue</big> <dfn></dfn></td>
<td><big>awo ofefe</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>Black</big> <dfn></dfn></td>
<td><big>awo dudu</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>White</big> <dfn></dfn></td>
<td><big>awo funfun</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Orange</big> <dfn></dfn></td>
<td><big>awo orun</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Brown</big> <dfn></dfn></td>
<td><big>awo eree</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
<br/> 
   <h1>Fruit <span style="text-decoration:underline;">means</span> <i style="color:#01415a;"><b>Eso</b></i></h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>Orange</big> <dfn> </dfn></td>
<td><big>Osan</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Pawpaw</big> <dfn> </dfn></td>
<td><big>ibepe</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Pine apple</big> <dfn></dfn></td>
<td><big>Opo Eyinbo</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>Mongo</big> <dfn></dfn></td>
<td><big>mongoro</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Bananas</big> <dfn></dfn></td>
<td><big>ogbede</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Apple</big> <dfn></dfn></td>
<td><big>apu</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>cerry </big> <dfn></dfn></td>
<td><big>agbalumo</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>

        <div class="container" id="phrases" style="display:none;">
            <br/> 
            <h1>Phrase <span style="text-decoration:underline;">means</span> <i style="color:#01415a;"><b> abuda oro  </b></i></h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>where is it?</big> <dfn> </dfn></td>
<td><big>ni bo lowa?</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>go home</big> <dfn></dfn></td>
<td><big>lo si ile</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>keep it</big> <dfn></dfn></td>
<td><big>fi pamo </big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>send it</big> <dfn></dfn></td>
<td><big>if ranse</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>finish it </big> <dfn></dfn></td>
<td><big>pari e</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>how are you?</big> <dfn></dfn></td>
<td><big>ba woni?</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>stand up</big> <dfn></dfn></td>
<td><big>dide duro</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>seat down</big> <dfn></dfn></td>
<td><big>joko</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>how much do you have?</big> <dfn></dfn></td>
<td><big>elo loni?</big>: <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>what is your name></big> <dfn></dfn></td>
<td><big>ki ni oruko re?</big>: <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>

        <div class="container" id="grammars" style="display:none;">
                    <br/>  abuda oro 
            <h1>Grammar <span style="text-decoration:underline;">means</span> <i style="color:#01415a;"><b> sisi so oro po </b></i> </h1>
            <h4>Two letter words <span style="text-decoration:underline;">means</span> <i style="color:#01415a;"><b>oro oni alifabeti meji</b></i></h4>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>
<tr><td><big>an</big> <dfn> </dfn></td>
<td><big>an</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>en</big> <dfn></dfn></td>
<td><big>en</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>en</big> <dfn></dfn></td>
<td><big>en</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>in</big> <dfn></dfn></td>
<td><big>in</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>o</big> <dfn></dfn></td>
<td><big>oo</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>o</big> <dfn></dfn></td>
<td><big>oo</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>u</big> <dfn></dfn></td>
<td><big>uu</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
 <br/>
<h4>three letter words <span style="text-decoration:underline;">means</span> <i style="color:#01415a;"><b>oro oni alifabeti meta</b></i></h4>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>two</big> <dfn> </dfn></td>
<td><big>eji</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>money</big> <dfn> </dfn></td>
<td><big>owo</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>cloths</big> <dfn></dfn></td>
<td><big>aso</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>leg</big> <dfn></dfn></td>
<td><big>ese</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>head</big> <dfn></dfn></td>
<td><big>ori</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>time</big> <dfn></dfn></td>
<td><big>igba</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>week</big> <dfn></dfn></td>
<td><big>ose</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
<br/>  ]
   <h4>Pronoun <span style="text-decoration:underline;">means</span> <i style="color:#01415a;"><b>oro aropo otuko</b></i></h4>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>you</big> <dfn> </dfn></td>
<td><big>iwo</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>me</big> <dfn> </dfn></td>
<td><big>emi</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>them</big> <dfn></dfn></td>
<td><big>awon</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>I</big> <dfn></dfn></td>
<td><big>emi</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>she</big> <dfn></dfn></td>
<td><big>oun</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>he</big> <dfn></dfn></td>
<td><big>oun</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>we</big> <dfn></dfn></td>
<td><big>awa</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
<br/> 
   <h1>Noun <span style="text-decoration:underline;">means</span> <i style="color:#01415a;"><b>Oro oruko</b></i></h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>grace</big> <dfn> </dfn></td>
<td><big>ore ofe</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>mercy</big> <dfn> </dfn></td>
<td><big>Aanu</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>State</big> <dfn></dfn></td>
<td><big>Ipinle</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>Country</big> <dfn></dfn></td>
<td><big>Orile ede</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Water</big> <dfn></dfn></td>
<td><big>Omi</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Air</big> <dfn></dfn></td>
<td><big>afefe</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Head</big> <dfn></dfn></td>
<td><big>Ori</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
<br/> Oro oruko
   <h1>Forming Sentences <span style="text-decoration:underline;">means</span> <i style="color:#01415a;"><b> Wiwun oropo</b></i></h1>
               <div class="table-responsive">
                      <table id="example2" class="table table-bordered table-hover"><tbody>
<tr><td><big>English</big> <dfn></dfn></td>
<td><big>Yoruba</big> <dfn></dfn></td>
<td><big>Voice</big> <dfn></dfn></td></tr>

<tr><td><big>i am a boy</big> <dfn> </dfn></td>
<td><big>okunrin ni mi</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>i am a girl</big> <dfn> </dfn></td>
<td><big>obinrin ni mi</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>what are you eat?</big> <dfn></dfn></td>
<td><big>kini oun tio n je?</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>


<tr><td><big>i am going home</big> <dfn></dfn></td>
<td><big>Mo n losi ile</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>What is your name?</big> <dfn></dfn></td>
<td><big>kini Oruko re?</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>Where are you coming from?</big> <dfn></dfn></td>
<td><big>ni bo ni o tin bo</big><dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

<tr><td><big>i am going to school</big> <dfn></dfn></td>
<td><big>mo n lo si ile iwe</big> <dfn></dfn></td>
<td><big></big>: <dfn>nisale</dfn></td></tr>

 </tbody></table>
</div>
        </div>
         
       
        </div>
       </section>
       
       <?php include ("head_foot/footer.php");?>
 <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/googleNew.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="js/app.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/page.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
             

             $(document).ready(function(){
    $( "#letter" ).click(function(){
        $("#letters").css("display","block");
        $("#numbers").css("display","none");
        $("#grammars").css("display","none");
        $("#phrases").css("display","none");
        $("#vocabularies").css("display","none");
        // $("#number").hide();
    });

      $( "#Number" ).click(function(){
        $("#letters").css("display","none");
         $("#grammars").css("display","none");
        $("#phrases").css("display","none");
        $("#vocabularies").css("display","none");
        $("#numbers").css("display","block");
        // $("#number").hide();
    }); $( "#Grammar" ).click(function(){
        $("#letters").css("display","none");
         $("#grammars").css("display","block");
        $("#phrases").css("display","none");
        $("#vocabularies").css("display","none");
        $("#numbers").css("display","none");
        // $("#number").hide();
    }); $( "#Vocabulary" ).click(function(){
        $("#letters").css("display","none");
         $("#grammars").css("display","none");
        $("#phrases").css("display","none");
        $("#vocabularies").css("display","block");
        $("#numbers").css("display","none");
        // $("#number").hide();
    }); $( "#Phrases" ).click(function(){
        $("#letters").css("display","none");
         $("#grammars").css("display","none");
        $("#phrases").css("display","block");
        $("#vocabularies").css("display","none");
        $("#numbers").css("display","none");
        // $("#number").hide();
    });
});
       </script>
    </body>
    </html>
