<!doctype html>
<html lang="en">
<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="icon" href="img/favicon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
        <title>About</title>
        
        <!-- Bootstrap CSS -->
   

        <link rel="stylesheet" href="css/responsive.css">
        <link href="css/ResponsiveDashboard.min.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/header.css">
         <script async src="js/google.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-4062475662821332",
    enable_page_level_ads: true
  });
</script>
    </head>
    <style type="text/css">
      
    </style>
    <body>
    <?php include ("head_foot/header.php");?>

     <section>
            
              <div class="content-wrapper" style=" min-height: 562px;">
       
                <div class="row">
                     <img class="img-responsive" style="width:100%" src="img/welcome4.jpg">
            </div>

            <div class="row">
             <h1>Welcom.....</h1>
            </div>
        </div>
       </section>
       <?php include ("head_foot/footer.php");?>

 <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/googleNew.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="js/app.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/page.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>