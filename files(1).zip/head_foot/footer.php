 <footer class="footer text-faded text-center py-5">
      <div class="container">
        <p class="m-0 small">Copyright &copy; Team Unifyconcept #NaijaHacks2018</p>
      </div>
    </footer>