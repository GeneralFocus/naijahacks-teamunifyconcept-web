

<header class="main-header">
        <!-- Logo -->
        <a href="#" class="logo">m<b>Tongue</b></a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
       
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav nav">
              <li id="li"><a href="">Home</a></li>
              <li id="li"><a href="">About</a></li>
              <li id="li"><a href="">Learn More</a></li>
            </ul>
          </div>
        </nav>
      </header>
                