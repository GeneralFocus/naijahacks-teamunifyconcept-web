

<header class="main-header" style="position:relative;">
        <!-- Logo -->
        <a href="#" class="logo">m<b>Tongue</b></a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" style="background-color: #0275a1; " role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <li id="li"><a href="index.php">Home</a></li>
              <!--li id="li"><a href="">About</a></li>
              <li id="li"><a href="">Learn More</a></li-->
            </ul>
          </div>
        </nav>
      </header>
                <!-- Left side column. contains the logo and sidebar -->
<!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar" style="position:fixed;">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">   
           
         
        <a class="logo">What To Learn </a>
          
          </div>
         
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            
<li class="treeview"><a href="hausa.php" title="Learn Hausa">Hausa</a></li>
<li class="treeview"><a href="igbo.php" title="Learn Igbo">Igbo</a></li>
<li class="treeview"><a href="yoruba.php" title="Learn Yoruba">Yoruba</a></li>
<li class="treeview"><a href="#" title=" ">Text To Speech</a></li>
<li class="treeview"><a href="#" title=" ">Take Test</a></li>
<li class="treeview"><a href="#" title=" ">More </a></li>

</ul>
        </section>
        <!-- /.sidebar -->
      </aside>
<!--hausa_inc.php-->
