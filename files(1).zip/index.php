<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mother's Tongue</title>
<meta name="description" content="">
<meta name="author" content="">

<!-- Favicons
    ================================================== -->
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="img/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">

<!-- Bootstrap -->
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.css">

<!-- Stylesheet
    ================================================== -->

     <!-- Start Free jQuery Slider HEAD section -->


<link rel="stylesheet" type="text/css" href="css/style1.css" />

<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/nivo-lightbox/nivo-lightbox.css">
<link rel="stylesheet" type="text/css" href="css/nivo-lightbox/default.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Start Free jQuery Slider HEAD section -->


<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/a.js"></script>
<!-- Free jQuery Slider HEAD section -->

</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
<!-- Navigation
    ==========================================-->
<nav id="menu" class="navbar navbar-default navbar-fixed-top">
  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand page-scroll" href="#page-top">Mother's Tongue</a>
      <div class="phone"><span>Call Today</span>+234 815 4422 572</div>
    </div>
    
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#about" class="page-scroll">About</a></li>
        <li><a href="#services" class="page-scroll">Services</a></li>
        <li><a href="#app" class="page-scroll">Mobile App</a></li>
        <li><a href="#contact" class="page-scroll">Contact</a></li>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
</nav>
<!-- Header -->
<header id="header">
  <div class="intro">
    <div class="overlay">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2 intro-text">
            <h1>Teaching <br>
              Languages</h1>
            <p>You Already Speak Your Mother's Tongue Learn Another</p>
            <a href="learn.php" class="btn btn-custom btn-lg page-scroll">Start Learning </a> </div>
        </div>
      </div>
    </div>
  </div>
</header>
<!-- Get Touch Section -->
<div id="get-touch">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-md-6 col-md-offset-1">
        <h3>Silence Is The Language Of gods</h3>
        <p>Speak while other's talk eradicate language barrier</p>
      </div>
      <div class="col-xs-12 col-md-4 text-center"><a href="learn.php" class="btn btn-custom btn-lg page-scroll">Learn Now</a></div>
    </div>
  </div>
</div>
<!-- About Section -->
<div id="about">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-md-6"> <img src="img/2.png" class="img-responsive" alt=""> </div>
      <div class="col-xs-12 col-md-6">
        <div class="about-text">
          <h2>Who We Are</h2>
          <p>We Are Magnificient Brand With Exclusive Leadership And Fabulous Skills Which Are On Standy To Tackle Any Difficulty Faced By You.</p>
          <h3>Why Choose Us?</h3>
          <div class="list-style">
            <div class="col-lg-6 col-sm-6 col-xs-12">
              <ul>
                <li>Years of Experience</li>
                <li>Fully Insured</li>
                <li>Cost Control Experts</li>
                <li>100% Satisfaction Guarantee</li>
              </ul>
            </div>
            <div class="col-lg-6 col-sm-6 col-xs-12">
              <ul>
                <li>Free Consultation</li>
                <li>Satisfied Customers</li>
                <li>Project Management</li>
                <li>Affordable Pricing</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Services Section -->
<div id="services">
  <div class="container">
    <div class="section-title">
      <h2>Our Services</h2>
    </div>
    <div class="row">
      <div class="col-md-4">
        <div class="service-media"> <img src="img/15295419.png" alt=" "> </div>
        <div class="service-desc">
          <h3>Teach Language</h3>
          <p>Don't be left out ofimportant conversation learn something from our experts</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="service-media"> <img src="img/trans.jpg" alt=" "> </div>
        <div class="service-desc">
          <h3>Translate</h3>
          <p>Find out what your friends are saying in their mother's tongue</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="service-media"> <img src="img/textToSpeech.jpg" alt=" "> </div>
        <div class="service-desc">
          <h3>Convert Text to Speech</h3>
          <p>We are here to make innovation simple for you, let speak those words out on a button click</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4">
        <div class="service-media"> <img src="img/examine (1).jpg" alt=" "> </div>
        <div class="service-desc">
          <h3>Certification</h3>
          <p>Become a certified in a language of your choice and prove your worth</p>
        </div>
      </div>
  </div>
</div>


<!-- Our Product -->
<div id="app">
  <div class="container">
    <div class="section-title">
      <h2>Our Mobile App</h2>
    </div>
<div id="wowslider-container1">
<div class="ws_images"><ul>
    <li><img src="img/mobile/slide1.jpg" alt="Railway Station" title="Download Now" id="wows1_0"/>click the upper Button</li>
    <li><img src="img/mobile/slide2.jpg" alt="Subway Station" title="Download Now" id="wows1_1"/>click the upper Button</li>
    <li><img src="img/mobile/slide3.jpg" alt="Train" title="Download Now" id="wows1_2"/>click the upper Button</li>
    <li><img src="img/mobile/slide4.jpg" alt="Train station" title="Download Now" id="wows1_3"/>click the upper Button</li>
    <li><img src="img/mobile/slide5.jpg" alt="Underground" title="Download Now" id="wows1_4"/>click the upper Button</li>
  </ul></div>
  
  <div class="ws_bullets"><div>
    <a href="#" title="Railway Station"><span><img src="img/mobile/slide1.jpg" alt="Railway Station"/>1</span></a>
    <a href="#" title="Subway Station"><span><img src="img/mobile/slide2.jpg" alt="Subway Station"/>2</span></a>
    <a href="#" title="Train"><span><img src="img/mobile/slide3.jpg" alt="Train"/>3</span></a>
    <a href="#" title="Train station"><span><img src="img/mobile/slide4.jpg" alt="Train station"/>4</span></a>
    <a href="#" title="Underground"><span><img src="img/mobile/slide5.jpg" alt="Underground"/>5</span></a>
  </div></div>
<div class="ws_shadow"></div>
</div>  

  </div>
</div>


<!-- Testimonials Section --
<div id="testimonials">
  <div class="container">
    <div class="section-title">
      <h2>Testimonials</h2>
    </div>
    <div class="row">
      <div class="col-md-4">
        <div class="testimonial">
          <div class="testimonial-image"> <img src="img/testimonials/01.jpg" alt=""> </div>
          <div class="testimonial-content">
            <p>"Loading...."</p>
            <div class="testimonial-meta"> -Guys  </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="testimonial">
          <div class="testimonial-image"> <img src="img/testimonials/02.jpg" alt=""> </div>
          <div class="testimonial-content">
            <p>"Loading...."</p>
            <div class="testimonial-meta"> - Guys  </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="testimonial">
          <div class="testimonial-image"> <img src="img/testimonials/03.jpg" alt=""> </div>
          <div class="testimonial-content">
            <p>"Loading...."</p>
            <div class="testimonial-meta"> -Guys  </div>
          </div>
        </div>
      </div>
      <div class="row"> </div>
      <div class="col-md-4">
        <div class="testimonial">
          <div class="testimonial-image"> <img src="img/testimonials/04.jpg" alt=""> </div>
          <div class="testimonial-content">
            <p>"Loading...."</p>
            <div class="testimonial-meta"> - Guys  </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="testimonial">
          <div class="testimonial-image"> <img src="img/testimonials/05.jpg" alt=""> </div>
          <div class="testimonial-content">
            <p>"Loading...."</p>
            <div class="testimonial-meta"> -Guys  </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="testimonial">
          <div class="testimonial-image"> <img src="img/testimonials/06.jpg" alt=""> </div>
          <div class="testimonial-content">
            <p>"Loading...."</p>
            <div class="testimonial-meta"> - Guys  </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>-->
<!-- Contact Section -->
<div id="contact">
  <div class="container">
    <div class="col-md-8">
      <div class="row">
        <div class="section-title">
          <h2>Get In Touch</h2>
          <p>Please fill out the form below to send us an email and we will get back to you as soon as possible.</p>
        </div>
        <form name="sentMessage" id="contactForm" novalidate>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <input type="text" id="name" class="form-control" placeholder="Name" required="required">
                <p class="help-block text-danger"></p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <input type="email" id="email" class="form-control" placeholder="Email" required="required">
                <p class="help-block text-danger"></p>
              </div>
            </div>
          </div>
          <div class="form-group">
            <textarea name="message" id="message" class="form-control" rows="4" placeholder="Message" required></textarea>
            <p class="help-block text-danger"></p>
          </div>
          <div id="success"></div>
          <button type="submit" class="btn btn-custom btn-lg">Send Message</button>
        </form>
      </div>
    </div>
    <div class="col-md-3 col-md-offset-1 contact-info">
      <div class="contact-item">
        <h4>Contact Info</h4>
        <p><span>Address</span><br>
         This is our domain</p>
      </div>
      <div class="contact-item">
        <p><span>Phone</span>+234 815 4422 572</p>
      </div>
      <div class="contact-item">
        <p><span>Email</span>info@u0582731.cp.hub8hosting.com</p>
      </div>
    </div>
    <div class="col-md-12">
      <div class="row">
        <div class="social">
          <ul>
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Footer Section -->
<div id="footer">
  <div class="container text-center">
    <p>&copy; Team UnifyConcept #NaijaHacks2018<a href="#" rel="nofollow"></a></p>
  </div>
</div>
<script type="text/javascript" src="js/jquery.1.11.1.js"></script> 
<script type="text/javascript" src="js/wowslider.js"></script> 
<script type="text/javascript" src="js/script.js"></script> 
<script type="text/javascript" src="js/bootstrap.js"></script> 
<script type="text/javascript" src="js/SmoothScroll.js"></script> 
<script type="text/javascript" src="js/nivo-lightbox.js"></script> 
<script type="text/javascript" src="js/jqBootstrapValidation.js"></script> 
<script type="text/javascript" src="js/contact_me.js"></script> 
<script type="text/javascript" src="js/main.js"></script>
</body>
</html>